import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-examinationtabguru',
  templateUrl: './examinationtabguru.page.html',
  styleUrls: ['./examinationtabguru.page.scss'],
})
export class ExaminationtabguruPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
