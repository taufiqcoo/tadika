import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-examinationtabpenjaga',
  templateUrl: './examinationtabpenjaga.page.html',
  styleUrls: ['./examinationtabpenjaga.page.scss'],
})
export class ExaminationtabpenjagaPage implements OnInit {

  constructor(private router: Router) { }

  

  ngOnInit() {
  }

}
