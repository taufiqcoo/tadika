import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-schedulepenjaga',
  templateUrl: './schedulepenjaga.page.html',
  styleUrls: ['./schedulepenjaga.page.scss'],
})
export class SchedulepenjagaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
