import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabsguru',
  templateUrl: './tabsguru.page.html',
  styleUrls: ['./tabsguru.page.scss'],
})
export class TabsguruPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
