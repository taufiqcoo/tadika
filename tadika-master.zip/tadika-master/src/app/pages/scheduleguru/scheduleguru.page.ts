import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scheduleguru',
  templateUrl: './scheduleguru.page.html',
  styleUrls: ['./scheduleguru.page.scss'],
})
export class ScheduleguruPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
